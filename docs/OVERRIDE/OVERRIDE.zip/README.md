# OVERRIDE
Over Ride selfbot coded in python

This is a selfbot relying on extensions, 
any one can make an extension

# How to install

1. Open Config.json

in config.json replace the prefix contents with the prefix you want
and replace the token content with your token
and delete-commands is true or false, if its true it deletes all commands you run

2. Extensions

make a folder in the selfbot folder
called extensions
put your extensions in there

3. Running the bot

run `selfbot.py`

# [Join The Discord Now](https://discord.gg/8n5GXWWt)